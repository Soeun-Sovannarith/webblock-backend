"""Trace headers on RabbitMQ messages (FR-13), on a plain header mapping, so no client library is
needed (aio-pika's ``Message.headers`` is one).

``inject`` puts ``x-request-id``, ``traceparent`` and ``tracestate`` of the current context into
the headers of a message being published, and removes any header that could carry a token, a user
or a caller. ``consume`` makes a message's trace and request ID the context of the work, as a system
context: no user and no caller is ever taken from a message."""

from __future__ import annotations

from collections.abc import Iterator, Mapping, MutableMapping
from contextlib import contextmanager
from typing import Any

from webblock_commons.core import context
from webblock_commons.core.context import OWN_HEADERS, REQUEST_ID, TRACEPARENT, TRACESTATE


def inject(headers: MutableMapping[str, Any]) -> MutableMapping[str, Any]:
    """Sets the trace headers of the current context on ``headers`` and returns it."""
    for name in [n for n in headers if n.lower() in OWN_HEADERS]:
        del headers[name]
    headers.update(context.outgoing_headers())
    return headers


def _values(headers: Mapping[str, Any], name: str) -> list[str]:
    """The text values of a header: text, or bytes read as UTF-8; any other type is ignored."""
    found: list[str] = []
    for key, value in headers.items():
        if key.lower() != name:
            continue
        if isinstance(value, bytes):
            value = value.decode("utf-8", "replace")
        if isinstance(value, str):
            found.append(value)
    return found


@contextmanager
def consume(headers: Mapping[str, Any]) -> Iterator[context.RequestContext]:
    """The context of the work a message starts: its request ID (or a new one) and trace."""
    ctx = context.incoming(
        _values(headers, REQUEST_ID),
        _values(headers, TRACEPARENT),
        _values(headers, TRACESTATE),
    )
    ctx.system = True
    with context.bound(ctx):
        yield ctx

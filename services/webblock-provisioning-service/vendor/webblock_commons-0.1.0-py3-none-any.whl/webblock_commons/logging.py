"""JSON log lines (FR-14) with the last guard against tokens (FR-15).

``JsonFormatter`` is a standard ``logging.Formatter``: one JSON object per line with the fixed
fields ``@timestamp``, ``level``, ``logger``, ``message``, ``exception`` (only with one), the
``request_id``, ``trace_id`` and ``span_id`` of the current context when known, and
``service.name`` and ``service.namespace`` from ``OTEL_SERVICE_NAME`` and
``OTEL_RESOURCE_ATTRIBUTES``; then the record's extra fields, except one named like a fixed field,
so an extra never replaces or forges one. Every text is redacted.
``structlog_processor`` adds the same fields for services that use structlog, without importing it.
"""

from __future__ import annotations

import json
import logging
import os
import sys
from collections.abc import Mapping, MutableMapping
from datetime import UTC, datetime
from typing import IO, Any, Final
from urllib.parse import unquote

from webblock_commons.core.context import log_fields
from webblock_commons.core.redact import redact

_MARK: Final = "_webblock_commons_handler"
_STANDARD: Final = frozenset(
    logging.LogRecord("", 0, "", 0, "", None, None).__dict__.keys()
    | {"message", "asctime", "taskName"}
)
FIXED: Final = frozenset(
    {
        "@timestamp",
        "level",
        "logger",
        "message",
        "exception",
        "request_id",
        "trace_id",
        "span_id",
        "service.name",
        "service.namespace",
    }
)
"""The fields the formatter writes itself (FR-14); an extra field of one of these names is
dropped."""


def service_fields(environ: Mapping[str, str]) -> dict[str, str]:
    """``service.name`` and ``service.namespace`` from the OpenTelemetry environment variables;
    ``OTEL_SERVICE_NAME`` wins over a ``service.name`` resource attribute."""
    fields: dict[str, str] = {}
    for item in environ.get("OTEL_RESOURCE_ATTRIBUTES", "").split(","):
        name, sep, value = item.partition("=")
        name = unquote(name.strip())
        if sep and name in ("service.name", "service.namespace") and value.strip():
            fields[name] = unquote(value.strip())
    if environ.get("OTEL_SERVICE_NAME"):
        fields["service.name"] = environ["OTEL_SERVICE_NAME"]
    return fields


def _clean(value: object) -> object:
    if isinstance(value, str):
        return redact(value)
    if isinstance(value, bool | int | float) or value is None:
        return value
    return redact(str(value))


class JsonFormatter(logging.Formatter):
    """One redacted JSON object per line. ``environ`` defaults to ``os.environ``, read once."""

    def __init__(self, environ: Mapping[str, str] | None = None) -> None:
        super().__init__()
        self._service = service_fields(os.environ if environ is None else environ)

    def format(self, record: logging.LogRecord) -> str:
        line: dict[str, object] = {}
        line["@timestamp"] = (
            datetime.fromtimestamp(record.created, UTC)
            .isoformat(timespec="milliseconds")
            .replace("+00:00", "Z")
        )
        line["level"] = record.levelname
        line["logger"] = record.name
        line["message"] = redact(record.getMessage())
        if record.exc_info:
            line["exception"] = redact(self.formatException(record.exc_info))
        line.update(log_fields())
        line.update(self._service)
        for name, value in record.__dict__.items():
            if name not in _STANDARD and name not in FIXED and not name.startswith("_"):
                line[name] = _clean(value)
        return json.dumps(line, ensure_ascii=False)


def structlog_processor(
    logger: object, method_name: str, event_dict: MutableMapping[str, Any]
) -> MutableMapping[str, Any]:
    """A structlog processor: redacts every value and adds the context and service fields, which
    win over values of the same name."""
    del logger, method_name
    for name, value in list(event_dict.items()):
        event_dict[name] = _clean(value)
    event_dict.update(log_fields())
    event_dict.update(service_fields(os.environ))
    return event_dict


def configure_logging(
    level: int = logging.INFO,
    stream: IO[str] | None = None,
    environ: Mapping[str, str] | None = None,
) -> logging.Handler:
    """Adds a handler with ``JsonFormatter`` on stdout (or ``stream``) to the root logger and
    returns it. A second call replaces the handler of the first, so no line is written twice."""
    handler = logging.StreamHandler(sys.stdout if stream is None else stream)
    handler.setFormatter(JsonFormatter(environ))
    setattr(handler, _MARK, True)
    root = logging.getLogger()
    for old in [h for h in root.handlers if getattr(h, _MARK, False)]:
        root.removeHandler(old)
    root.addHandler(handler)
    root.setLevel(level)
    return handler

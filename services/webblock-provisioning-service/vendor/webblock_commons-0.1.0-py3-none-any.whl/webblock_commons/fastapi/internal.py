"""The allowed-callers one-liner for internal REST endpoints (FR-7, FR-8, FR-4).

``allowed_callers`` is a dependency for each internal route: the method key is
``<HTTP method> <path template>`` of the matched route (``GET /internal/v1/things/{thing_id}``).
``check_internal_routes`` refuses an app with an internal route that lacks it. Both live in
``dependencies``; this module names them for internal routes."""

from __future__ import annotations

from webblock_commons.fastapi.dependencies import allowed_callers, check_internal_routes, method_key

__all__ = ["allowed_callers", "check_internal_routes", "method_key"]

"""Problem Details answers for FastAPI (FR-10): a ``WebBlockProblem`` becomes the RFC 9457 document
of FR-10, with ``instance`` the request path (never the query string) and ``requestId`` and
``traceId`` from the request context. Each refusal writes one log line with the code and status
only."""

from __future__ import annotations

import logging
from typing import Final

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, Response

from webblock_commons.core import context
from webblock_commons.core.errors import WebBlockProblem, problem_body, problem_media_type
from webblock_commons.core.traceparent import new_request_id

LOG: Final = logging.getLogger("webblock_commons")


def problem_response(request: Request, problem: WebBlockProblem) -> Response:
    """The answer to ``problem`` for ``request``."""
    ctx = context.current()
    body = problem_body(
        problem.error,
        instance=request.url.path,
        request_id=ctx.request_id if ctx else new_request_id(),
        trace_id=ctx.trace_id if ctx else None,
    )
    LOG.info("request refused", extra={"code": problem.error.code, "status": problem.error.status})
    return JSONResponse(
        body,
        status_code=problem.error.status,
        media_type=problem_media_type(request.headers.getlist("accept")),
    )


async def handle_problem(request: Request, exc: Exception) -> Response:
    """The exception handler: a ``WebBlockProblem`` is answered, anything else is raised again."""
    if isinstance(exc, WebBlockProblem):
        return problem_response(request, exc)
    raise exc


def install_problem_handler(app: FastAPI) -> None:
    """Registers the problem answer for ``WebBlockProblem`` on ``app``."""
    app.add_exception_handler(WebBlockProblem, handle_problem)

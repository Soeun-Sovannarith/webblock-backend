"""FastAPI dependencies for the one-liners (FR-4, FR-5, FR-7): ``signed_in``, ``admins_only`` and
``project_access`` return the ``WebBlockUser``; ``allowed_callers`` guards an internal route.
``install`` puts the library on an app.

Every route under the internal prefix (``/internal`` by default) must depend on
``allowed_callers``: ``check_internal_routes`` refuses an app with a route there that does not, and
``install`` runs it when the app starts (its lifespan), so such a service does not start. It runs
again on the first request, so an app served without its lifespan answers 500 ``INTERNAL_ERROR``
instead. A route whose path starts with a path parameter (``/{service}/things``) could serve a path
under the prefix, so it counts as under it. On a path under the prefix ``signed_in`` never reads the
token: it runs the caller check instead."""

from __future__ import annotations

import logging
import uuid
from collections.abc import AsyncIterator, Awaitable, Callable, Iterator, Mapping
from contextlib import asynccontextmanager
from dataclasses import dataclass
from typing import Annotated, Any, Final, cast

from fastapi import Depends, FastAPI, Request
from fastapi.dependencies.models import Dependant
from fastapi.routing import APIRoute, APIWebSocketRoute, iter_route_contexts
from starlette.routing import Route
from starlette.types import Lifespan

from webblock_commons.core import context, errors
from webblock_commons.core.access import Access
from webblock_commons.core.caller import Caller, inner_call
from webblock_commons.core.context import DEV_CALLER, USER_ID, XFCC
from webblock_commons.core.errors import ErrorCode, WebBlockProblem
from webblock_commons.core.settings import Settings
from webblock_commons.core.user import WebBlockUser, current_user, require_admin
from webblock_commons.core.verifier import TokenVerifier
from webblock_commons.fastapi.middleware import RequestContextMiddleware
from webblock_commons.fastapi.problems import install_problem_handler

_STATE: Final = "webblock_commons"
INTERNAL_PREFIX: Final = "/internal"
LOG: Final = logging.getLogger("webblock_commons")


@dataclass(frozen=True, slots=True)
class Installed:
    """What ``install`` put on the app."""

    settings: Settings
    verifier: TokenVerifier
    access: Access | None
    internal_prefix: str = INTERNAL_PREFIX


def install(
    app: FastAPI,
    *,
    settings: Settings,
    verifier: TokenVerifier,
    access: Access | None = None,
    internal_prefix: str = INTERNAL_PREFIX,
) -> None:
    """Adds the request context middleware and the problem handler, keeps the settings, the
    token verifier and the project access one-liner for the dependencies, and makes the app's
    start-up and its first request run ``check_internal_routes``."""
    if not internal_prefix.startswith("/") or internal_prefix.endswith("/"):
        raise ValueError("webblock_commons: internal_prefix is a path such as /internal")
    setattr(
        app.state,
        _STATE,
        Installed(
            settings=settings, verifier=verifier, access=access, internal_prefix=internal_prefix
        ),
    )
    app.add_middleware(RequestContextMiddleware, check=lambda: check_internal_routes(app))
    install_problem_handler(app)
    started = app.router.lifespan_context

    @asynccontextmanager
    async def checked(target: Any) -> AsyncIterator[Mapping[str, Any] | None]:
        check_internal_routes(app)
        async with started(target) as state:
            yield state

    app.router.lifespan_context = cast("Lifespan[Any]", checked)


def _under(path: str, prefix: str) -> bool:
    return path == prefix or path.startswith(prefix + "/")


def _may_serve(path: str, prefix: str) -> bool:
    """Whether a route template may serve a path under the prefix: it is under it, or it starts
    with a path parameter."""
    return _under(path, prefix) or path.startswith("/{")


def _calls(dependant: Dependant) -> Iterator[Callable[..., Any] | None]:
    for dependency in dependant.dependencies:
        yield dependency.call
        yield from _calls(dependency)


def check_internal_routes(app: FastAPI) -> None:
    """Refuses (``RuntimeError``, naming the route) an app with a route under the internal prefix,
    or one whose path starts with a path parameter, that does not depend on ``allowed_callers``, or
    anything else mounted there. Warns for an internal method with no allowed-callers entry, which
    allows nobody."""
    state = getattr(app.state, _STATE, None)
    if not isinstance(state, Installed):
        raise RuntimeError("webblock_commons: install(app, ...) was not called")
    prefix = state.internal_prefix
    for found in iter_route_contexts(app.routes):
        path = found.path or ""
        if not _may_serve(path, prefix):
            continue
        dependant = getattr(found, "dependant", None)
        if (
            not isinstance(found.original_route, APIRoute | APIWebSocketRoute)
            or not isinstance(dependant, Dependant)
            or not any(call is allowed_callers for call in _calls(dependant))
        ):
            raise RuntimeError(
                f"webblock_commons: the internal route {path} does not depend on allowed_callers"
            )
        for method in sorted(found.methods or ()):
            if f"{method} {found.path_format}" not in state.settings.allowed_callers:
                LOG.warning(
                    "an internal method has no allowed callers and refuses every call",
                    extra={"method": f"{method} {found.path_format}"},
                )


def installed(request: Request) -> Installed:
    """The library's state on the app; ``INTERNAL_ERROR`` when ``install`` was not called."""
    found = getattr(request.app.state, _STATE, None)
    if not isinstance(found, Installed) or context.current() is None:
        raise WebBlockProblem(errors.INTERNAL_ERROR)
    return found


async def signed_in(request: Request) -> WebBlockUser:
    """The current user. On a token request the bearer token is checked once per request; on an
    inner call it is the inner user, and the token is never read: on a path under the internal
    prefix the caller check runs instead."""
    state = installed(request)
    ctx = context.current()
    assert ctx is not None  # noqa: S101 - installed() checked it
    if not ctx.system and _under(request.url.path, state.internal_prefix):
        await allowed_callers(request)
    if ctx.system:
        return current_user()
    if ctx.user is None:
        ctx.user = await state.verifier.user(request.headers.getlist("authorization"))
    return ctx.user


async def admins_only(user: Annotated[WebBlockUser, Depends(signed_in)]) -> WebBlockUser:
    """The current user when ``ADMIN`` is in the token's roles; 403 otherwise."""
    del user
    return require_admin()


def project_access(
    action: str, not_found: ErrorCode = errors.PROJECT_NOT_FOUND
) -> Callable[..., Awaitable[WebBlockUser]]:
    """A dependency for a route with a ``project_id`` path parameter: the current user when they
    may do ``action`` on that project (FR-5, FR-6). ``INTERNAL_ERROR`` when no ``Access`` was
    installed."""

    async def dependency(
        project_id: uuid.UUID,
        request: Request,
        user: Annotated[WebBlockUser, Depends(signed_in)],
    ) -> WebBlockUser:
        del user
        access = installed(request).access
        if access is None:
            raise WebBlockProblem(errors.INTERNAL_ERROR)
        return await access.require_project(project_id, action, not_found)

    return dependency


def method_key(request: Request) -> str:
    """``<HTTP method> <path template>`` of the matched route."""
    route = request.scope.get("route")
    if not isinstance(route, Route):
        raise WebBlockProblem(errors.INTERNAL_ERROR)
    return f"{request.method} {route.path_format}"


async def allowed_callers(request: Request) -> Caller:
    """The caller of an internal call when it is on the route's list; 401 or 403 otherwise. It
    reads ``X-Forwarded-Client-Cert`` (or ``X-Webblock-Dev-Caller`` in dev mode) and
    ``X-User-Id``, never ``Authorization``, and makes the request a system context with that caller
    and inner user."""
    state = installed(request)
    ctx = context.current()
    assert ctx is not None  # noqa: S101 - installed() checked it
    caller, user = inner_call(
        state.settings,
        method_key(request),
        xfcc=request.headers.getlist(XFCC),
        dev_caller=request.headers.getlist(DEV_CALLER),
        user_id=request.headers.getlist(USER_ID),
    )
    ctx.caller, ctx.user, ctx.system = caller, user, True
    return caller

"""The request context middleware (FR-12): pure ASGI (not ``BaseHTTPMiddleware``), so the
context lives in the request's own task. It reads ``x-request-id``, ``traceparent`` and
``tracestate``, binds the context for the request and returns ``x-request-id`` on the response,
refusals included. It never reads or logs any other header.

With ``check`` (``install`` passes the internal route check, FR-7) the first request runs the
check once; when it fails, every request answers 500 ``INTERNAL_ERROR``, so an app started without
its lifespan still never serves an unguarded internal route."""

from __future__ import annotations

import json
import logging
from collections.abc import Callable, Sequence
from typing import Final

from starlette.types import ASGIApp, Message, Receive, Scope, Send

from webblock_commons.core import context, errors
from webblock_commons.core.context import REQUEST_ID, TRACEPARENT, TRACESTATE
from webblock_commons.core.errors import problem_body, problem_media_type

_REQUEST_ID: Final = REQUEST_ID.encode("ascii")
LOG: Final = logging.getLogger("webblock_commons")


def header_values(scope: Scope, name: bytes) -> list[str]:
    """Every value of header ``name`` (lower case) in an ASGI scope."""
    raw: Sequence[tuple[bytes, bytes]] = scope.get("headers", ())
    return [value.decode("latin-1") for key, value in raw if key.lower() == name]


class RequestContextMiddleware:
    """Binds the request context of each HTTP request."""

    def __init__(self, app: ASGIApp, check: Callable[[], None] | None = None) -> None:
        self.app = app
        self._check = check
        self._refused = False

    def _checked(self) -> bool:
        """Runs ``check`` on the first request; True while it has not failed."""
        if self._check is not None:
            check, self._check = self._check, None
            try:
                check()
            except RuntimeError:
                LOG.exception("the internal route check failed: every request answers 500")
                self._refused = True
        return not self._refused

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return
        ctx = context.incoming(
            header_values(scope, _REQUEST_ID),
            header_values(scope, TRACEPARENT.encode("ascii")),
            header_values(scope, TRACESTATE.encode("ascii")),
        )

        async def send_with_request_id(message: Message) -> None:
            if message["type"] == "http.response.start":
                headers = [
                    (k, v) for k, v in message.get("headers", []) if k.lower() != _REQUEST_ID
                ]
                headers.append((_REQUEST_ID, ctx.request_id.encode("ascii")))
                message = {**message, "headers": headers}
            await send(message)

        with context.bound(ctx):
            if self._checked():
                await self.app(scope, receive, send_with_request_id)
            else:
                await _internal_error(scope, ctx, send_with_request_id)


async def _internal_error(scope: Scope, ctx: context.RequestContext, send: Send) -> None:
    """Answers the problem of ``INTERNAL_ERROR`` (FR-10) without running the app."""
    body = problem_body(
        errors.INTERNAL_ERROR,
        instance=str(scope.get("path", "")),
        request_id=ctx.request_id,
        trace_id=ctx.trace_id,
    )
    media = problem_media_type(header_values(scope, b"accept"))
    data = json.dumps(body, separators=(",", ":")).encode("utf-8")
    await send(
        {
            "type": "http.response.start",
            "status": errors.INTERNAL_ERROR.status,
            "headers": [
                (b"content-type", media.encode("ascii")),
                (b"content-length", str(len(data)).encode("ascii")),
            ],
        }
    )
    await send({"type": "http.response.body", "body": data})

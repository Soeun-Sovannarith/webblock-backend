"""FastAPI integration of webblock_commons (needs the extra fastapi)."""

from webblock_commons.fastapi.dependencies import (
    admins_only,
    allowed_callers,
    check_internal_routes,
    install,
    project_access,
    signed_in,
)

__all__ = [
    "admins_only",
    "allowed_callers",
    "check_internal_routes",
    "install",
    "project_access",
    "signed_in",
]

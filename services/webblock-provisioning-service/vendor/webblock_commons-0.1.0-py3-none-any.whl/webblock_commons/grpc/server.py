"""The gRPC server side (FR-7, FR-8, FR-11, FR-12): every method of a server with this interceptor
is internal. For each call it binds the request context (``x-request-id``, ``traceparent``,
``tracestate``), checks the caller against the method's allowed list, takes the inner user from
``x-user-id``, never reads ``authorization``, and turns a ``WebBlockProblem`` raised by the method
into the status and ``ErrorInfo`` of FR-11. A method that ends with a status of its own keeps it:
``context.abort`` as the method sent it, an ``AioRpcError`` of a call it made with that status and
its name as the message (none of its text or trailers). Any other exception answers
``INTERNAL_ERROR`` with no text of the exception, and is logged.

Serve with a small message size limit (``SERVER_OPTIONS``, 64 KiB): the caller check runs after
the request message is read."""

from __future__ import annotations

import logging
from collections.abc import AsyncIterator, Awaitable, Callable, Sequence
from contextlib import asynccontextmanager
from typing import Any, Final

import grpc
import grpc.aio

from webblock_commons.core import context, errors
from webblock_commons.core.caller import inner_call
from webblock_commons.core.context import (
    DEV_CALLER,
    REQUEST_ID,
    TRACEPARENT,
    TRACESTATE,
    USER_ID,
    XFCC,
)
from webblock_commons.core.errors import WebBlockProblem
from webblock_commons.core.settings import Settings
from webblock_commons.grpc.status import abort_with_problem

type Metadata = Sequence[tuple[str, str | bytes]]

MAX_MESSAGE_BYTES: Final = 64 * 1024
SERVER_OPTIONS: Final = (
    ("grpc.max_receive_message_length", MAX_MESSAGE_BYTES),
    ("grpc.max_send_message_length", MAX_MESSAGE_BYTES),
)
"""Options for ``grpc.aio.server(options=...)``: internal messages are small."""
LOG: Final = logging.getLogger("webblock_commons")


def _values(metadata: Metadata, name: str) -> list[str]:
    return [value for key, value in metadata if key.lower() == name and isinstance(value, str)]


def _incoming(metadata: Metadata) -> context.RequestContext:
    """The context of a call from its metadata; the user, if any, never comes from a token."""
    ctx = context.incoming(
        _values(metadata, REQUEST_ID),
        _values(metadata, TRACEPARENT),
        _values(metadata, TRACESTATE),
    )
    ctx.system = True
    return ctx


class InternalCallInterceptor(grpc.aio.ServerInterceptor):  # type: ignore[misc]  # grpc ships no types
    """Applies the inner call rules to every method of the server."""

    def __init__(self, settings: Settings) -> None:
        self._settings = settings

    @asynccontextmanager
    async def _call(
        self, method: str, metadata: Metadata, ctx: grpc.aio.ServicerContext[Any, Any]
    ) -> AsyncIterator[None]:
        """Binds the call's context, runs the caller check, and turns what the method raises into
        the answer of FR-11."""
        with context.bound(_incoming(metadata)) as bound:
            try:
                bound.caller, bound.user = inner_call(
                    self._settings,
                    method,
                    xfcc=_values(metadata, XFCC),
                    dev_caller=_values(metadata, DEV_CALLER),
                    user_id=_values(metadata, USER_ID),
                )
                yield
            except WebBlockProblem as problem:
                await abort_with_problem(ctx, problem, self._settings.domain)
            except grpc.aio.AbortError:
                raise
            except grpc.aio.AioRpcError as failure:
                code = failure.code()
                await ctx.abort(code, code.name)
            except Exception:
                LOG.exception("unexpected error in a gRPC method")
                await abort_with_problem(
                    ctx, WebBlockProblem(errors.INTERNAL_ERROR), self._settings.domain
                )

    async def intercept_service(
        self,
        continuation: Callable[[grpc.HandlerCallDetails], Awaitable[grpc.RpcMethodHandler]],
        handler_call_details: grpc.HandlerCallDetails,
    ) -> grpc.RpcMethodHandler:
        handler = await continuation(handler_call_details)
        if handler is None:
            return None
        method: str = handler_call_details.method
        metadata: Metadata = tuple(handler_call_details.invocation_metadata or ())
        call = self._call

        def unary(behavior: Callable[..., Awaitable[Any]]) -> Callable[..., Awaitable[Any]]:
            async def run(request: Any, ctx: grpc.aio.ServicerContext[Any, Any]) -> Any:
                result = None  # stays None when the call ended with an error answer
                async with call(method, metadata, ctx):
                    result = await behavior(request, ctx)
                return result  # noqa: RET504 - the block may end in an error answer

            return run

        def streaming(behavior: Callable[..., AsyncIterator[Any]]) -> Callable[..., Any]:
            async def run(request: Any, ctx: grpc.aio.ServicerContext[Any, Any]) -> Any:
                async with call(method, metadata, ctx):
                    async for item in behavior(request, ctx):
                        yield item

            return run

        options = {
            "request_deserializer": handler.request_deserializer,
            "response_serializer": handler.response_serializer,
        }
        if handler.unary_unary:
            return grpc.unary_unary_rpc_method_handler(unary(handler.unary_unary), **options)
        if handler.stream_unary:
            return grpc.stream_unary_rpc_method_handler(unary(handler.stream_unary), **options)
        if handler.unary_stream:
            return grpc.unary_stream_rpc_method_handler(streaming(handler.unary_stream), **options)
        return grpc.stream_stream_rpc_method_handler(streaming(handler.stream_stream), **options)


def server_interceptor(settings: Settings) -> InternalCallInterceptor:
    """The interceptor to pass to ``grpc.aio.server(interceptors=[...])``."""
    return InternalCallInterceptor(settings)

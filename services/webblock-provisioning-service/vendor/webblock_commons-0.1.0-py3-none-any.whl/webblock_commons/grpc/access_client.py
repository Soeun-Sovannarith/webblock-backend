"""The CheckAccess client (FR-5, FR-6, ARCH 3.6): ``webblock.project.v1.AccessService/CheckAccess``
with a 2 s deadline per attempt, retrying only ``UNAVAILABLE``, at most twice, after 100 ms and then
200 ms.
Any other end, the deadline included, is final. No answer means ``ACCESS_UNAVAILABLE`` (503), never
"allowed". Each call carries ``x-request-id`` and the trace headers, never ``authorization``."""

from __future__ import annotations

import asyncio
import uuid
from typing import Final

import grpc
import grpc.aio

from webblock_commons._gen.webblock.project.v1 import access_pb2
from webblock_commons.core import context, errors
from webblock_commons.core.access import AccessAnswer
from webblock_commons.core.errors import WebBlockProblem

METHOD: Final = "/webblock.project.v1.AccessService/CheckAccess"
DEADLINE_SECONDS: Final = 2.0
RETRY_WAITS: Final = (0.1, 0.2)
"""The wait before the second call and before the third (FR-6)."""


class GrpcProjectAccessClient:
    """A ``ProjectAccessLookup`` over gRPC, on a channel the service opens to Project."""

    __slots__ = ("_call", "_retry_waits", "deadline")

    def __init__(
        self,
        channel: grpc.aio.Channel,
        *,
        deadline: float = DEADLINE_SECONDS,
        retry_waits: tuple[float, ...] = RETRY_WAITS,
    ) -> None:
        self.deadline = deadline
        self._retry_waits = retry_waits
        self._call = channel.unary_unary(
            METHOD,
            request_serializer=access_pb2.CheckAccessRequest.SerializeToString,
            response_deserializer=access_pb2.CheckAccessResponse.FromString,
        )

    async def check_access(
        self, user_id: uuid.UUID, project_id: uuid.UUID, action: str
    ) -> AccessAnswer:
        request = access_pb2.CheckAccessRequest(
            user_id=str(user_id), project_id=str(project_id), action=action
        )
        metadata = tuple(context.outgoing_headers().items())
        waits = list(self._retry_waits)
        while True:
            try:
                response = await self._call(request, metadata=metadata, timeout=self.deadline)
            except grpc.aio.AioRpcError as err:
                if err.code() == grpc.StatusCode.UNAVAILABLE and waits:
                    await asyncio.sleep(waits.pop(0))
                    continue
                raise WebBlockProblem(errors.ACCESS_UNAVAILABLE) from None
            return AccessAnswer(allowed=bool(response.allowed), reason=str(response.reason))

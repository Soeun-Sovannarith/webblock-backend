"""gRPC calls to our own services (FR-9): ``internal_channel`` builds a ``grpc.aio`` channel whose
interceptor removes ``authorization`` and every metadata key only the library may set, then adds
``x-request-id``, ``traceparent``, ``tracestate`` and the current user's ``x-user-id``. Channels
built any other way are never touched."""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

import grpc
import grpc.aio

from webblock_commons.core.context import OWN_HEADERS, internal_headers


def _details(details: grpc.aio.ClientCallDetails) -> grpc.aio.ClientCallDetails:
    kept = [(k, v) for k, v in (details.metadata or ()) if k.lower() not in OWN_HEADERS]
    metadata = grpc.aio.Metadata(*kept, *internal_headers().items())
    return grpc.aio.ClientCallDetails(
        details.method, details.timeout, metadata, details.credentials, details.wait_for_ready
    )


class _UnaryUnary(grpc.aio.UnaryUnaryClientInterceptor):  # type: ignore[misc]  # grpc: no types
    async def intercept_unary_unary(
        self, continuation: Callable[..., Any], details: Any, request: Any
    ) -> Any:
        return await continuation(_details(details), request)


class _UnaryStream(grpc.aio.UnaryStreamClientInterceptor):  # type: ignore[misc]  # grpc: no types
    async def intercept_unary_stream(
        self, continuation: Callable[..., Any], details: Any, request: Any
    ) -> Any:
        return await continuation(_details(details), request)


class _StreamUnary(grpc.aio.StreamUnaryClientInterceptor):  # type: ignore[misc]  # grpc: no types
    async def intercept_stream_unary(
        self, continuation: Callable[..., Any], details: Any, requests: Any
    ) -> Any:
        return await continuation(_details(details), requests)


class _StreamStream(grpc.aio.StreamStreamClientInterceptor):  # type: ignore[misc]  # grpc: no types
    async def intercept_stream_stream(
        self, continuation: Callable[..., Any], details: Any, requests: Any
    ) -> Any:
        return await continuation(_details(details), requests)


def internal_interceptors() -> list[grpc.aio.ClientInterceptor]:
    """The client interceptors of the internal call rules, one per call kind (grpc.aio registers
    an interceptor object for one kind only)."""
    return [_UnaryUnary(), _UnaryStream(), _StreamUnary(), _StreamStream()]


def internal_channel(target: str, **options: Any) -> grpc.aio.Channel:
    """A plaintext ``grpc.aio`` channel to one of our services (the mesh adds mTLS)."""
    interceptors = [*internal_interceptors(), *options.pop("interceptors", ())]
    return grpc.aio.insecure_channel(target, interceptors=interceptors, **options)

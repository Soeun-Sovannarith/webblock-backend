"""gRPC refusals (FR-11): the status of ARCH 2.3, the code's title as the message, and one
``google.rpc.ErrorInfo`` with ``reason`` the code, ``domain`` ``<service>.webblock`` and
``metadata.request_id``, sent in the ``grpc-status-details-bin`` trailer."""

from __future__ import annotations

import logging
from typing import Final

import grpc
import grpc.aio
from google.protobuf import any_pb2
from google.rpc import error_details_pb2, status_pb2

from webblock_commons.core import context
from webblock_commons.core.errors import ErrorCode, WebBlockProblem

DETAILS_KEY: Final = "grpc-status-details-bin"
LOG: Final = logging.getLogger("webblock_commons")


def status_code(error: ErrorCode) -> grpc.StatusCode:
    """The gRPC status of ``error``."""
    return grpc.StatusCode[error.grpc_status]


def status_details(error: ErrorCode, domain: str, request_id: str | None) -> bytes:
    """The serialized ``google.rpc.Status`` with one ``ErrorInfo``."""
    info = error_details_pb2.ErrorInfo(reason=error.code, domain=domain)
    if request_id is not None:
        info.metadata["request_id"] = request_id
    detail = any_pb2.Any()
    detail.Pack(info)
    status = status_pb2.Status(
        code=status_code(error).value[0], message=error.title, details=[detail]
    )
    return bytes(status.SerializeToString())


async def abort_with_problem(
    ctx: grpc.aio.ServicerContext[object, object], problem: WebBlockProblem, domain: str
) -> None:
    """Ends the call with ``problem`` (``abort`` raises); logs the code and status only."""
    error = problem.error
    current = context.current()
    LOG.info("request refused", extra={"code": error.code, "status": error.status})
    details = status_details(error, domain, current.request_id if current else None)
    await ctx.abort(status_code(error), error.title, trailing_metadata=((DETAILS_KEY, details),))

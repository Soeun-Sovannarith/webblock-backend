"""webblock_commons: shared auth and telemetry glue of the WebBlock services (DESIGN.md)."""

__version__ = "0.1.0"

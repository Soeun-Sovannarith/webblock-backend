"""Project access and owner of record (FR-4, FR-5, FR-6).

``Access.require_project`` is the owner (or admin) one-liner: an admin (``ADMIN`` in the token's
roles; an inner user never is) passes without a call only on an admin-allowed action; everyone else
is checked with a ``ProjectAccessLookup``, the gRPC CheckAccess client or, inside Project, a local
lookup the service provides. Not allowed answers 404 with the given code; ``PROJECT_DELETED`` or
``PROJECT_SUSPENDED`` on a write action answers 409 with that code. No answer is ever cached.
``require_owner`` is the owner-of-record one-liner."""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from typing import Final, Protocol

from webblock_commons.core import errors
from webblock_commons.core.actions import ActionList
from webblock_commons.core.errors import ErrorCode, WebBlockProblem
from webblock_commons.core.user import WebBlockUser, current_user

_ON_WRITE: Final = {
    errors.PROJECT_DELETED.code: errors.PROJECT_DELETED,
    errors.PROJECT_SUSPENDED.code: errors.PROJECT_SUSPENDED,
}


@dataclass(frozen=True, slots=True)
class AccessAnswer:
    """Project's answer: allowed, or refused with a reason."""

    allowed: bool
    reason: str = ""


class ProjectAccessLookup(Protocol):
    """Asks Project whether ``user_id`` may do ``action`` on ``project_id``. Raises
    ``WebBlockProblem(ACCESS_UNAVAILABLE)`` when no answer can be had."""

    async def check_access(
        self, user_id: uuid.UUID, project_id: uuid.UUID, action: str
    ) -> AccessAnswer: ...


class Access:
    """The project access one-liner, with the action list and the lookup it asks."""

    __slots__ = ("_actions", "_lookup")

    def __init__(self, actions: ActionList, lookup: ProjectAccessLookup) -> None:
        self._actions = actions
        self._lookup = lookup

    async def require_project(
        self, project_id: uuid.UUID, action: str, not_found: ErrorCode = errors.PROJECT_NOT_FOUND
    ) -> WebBlockUser:
        """The current user when they may do ``action`` on ``project_id``; a problem otherwise."""
        user = current_user()
        known = self._actions.get(action)
        if known is None:
            raise WebBlockProblem(errors.INTERNAL_ERROR)
        if user.is_admin and known.admin_allowed:
            return user
        answer = await self._lookup.check_access(user.user_id, project_id, action)
        if answer.allowed:
            return user
        if known.write and answer.reason in _ON_WRITE:
            raise WebBlockProblem(_ON_WRITE[answer.reason])
        raise WebBlockProblem(not_found)

    def require_owner(self, record_user_id: uuid.UUID, not_found: ErrorCode) -> WebBlockUser:
        return require_owner(record_user_id, not_found)


def require_owner(record_user_id: uuid.UUID, not_found: ErrorCode) -> WebBlockUser:
    """The current user when the record's stored ``user_id`` is theirs; 404 with ``not_found``
    otherwise (admins too), the same answer as for a record that does not exist."""
    user = current_user()
    if user.user_id != record_user_id:
        raise WebBlockProblem(not_found)
    return user

"""The action list (FR-5, FR-6, TR-5): each CheckAccess action, its admin-allowed and write flags.

The shared list lives in ``web-block-contracts`` (``access/actions.v1.json``); the package carries
the copy pinned in ``contracts.lock``, which ``ActionList.default()`` reads. A service that must use
another list passes it to ``ActionList.from_file``. An action not on the list is refused with 500
``INTERNAL_ERROR`` and no call."""

from __future__ import annotations

import json
import re
from collections.abc import Mapping
from dataclasses import dataclass
from importlib import resources
from pathlib import Path
from types import MappingProxyType
from typing import Final

_NAME: Final = re.compile(r"[a-z][a-z0-9_]*", re.ASCII)
_FIELDS: Final = frozenset({"name", "admin_allowed", "write"})
MAX_BYTES: Final = 1024 * 1024
PACKAGED: Final = "actions.v1.json"


@dataclass(frozen=True, slots=True)
class Action:
    """One action: an admin passes it without a call when ``admin_allowed``; a deleted or suspended
    project answers 409 on it only when ``write``."""

    name: str
    admin_allowed: bool
    write: bool


class ActionList:
    """The known actions by name. Read-only."""

    __slots__ = ("_actions",)

    def __init__(self, actions: Mapping[str, Action]) -> None:
        self._actions = MappingProxyType(dict(actions))

    @classmethod
    def from_json(cls, document: object) -> ActionList:
        """The list of ``{"actions": [{"name", "admin_allowed", "write"}, ...]}``; ``ValueError``
        for anything else (fail closed: a bad list is not used)."""
        items = document.get("actions") if isinstance(document, dict) else None
        if not isinstance(items, list):
            raise ValueError("action list: no actions")
        actions: dict[str, Action] = {}
        for item in items:
            if not isinstance(item, dict) or set(item) != _FIELDS:
                raise ValueError("action list: each action has name, admin_allowed and write")
            name, admin, write = item["name"], item["admin_allowed"], item["write"]
            if not isinstance(name, str) or _NAME.fullmatch(name) is None or name in actions:
                raise ValueError("action list: a name is malformed or repeated")
            if not isinstance(admin, bool) or not isinstance(write, bool):
                raise ValueError("action list: the flags must be true or false")
            actions[name] = Action(name, admin, write)
        return cls(actions)

    @classmethod
    def from_file(cls, path: Path) -> ActionList:
        """The list in ``path``; ``ValueError`` for a file over 1 MiB or a bad list, and
        ``OSError`` for a file that cannot be read, so the service does not start."""
        with path.open("rb") as handle:
            return cls._from_bytes(handle.read(MAX_BYTES + 1))

    @classmethod
    def default(cls) -> ActionList:
        """The pinned list the package carries (``webblock_commons/core/actions.v1.json``), the
        same list as the Java starter's default; the errors of ``from_file``."""
        with resources.files(__package__).joinpath(PACKAGED).open("rb") as handle:
            return cls._from_bytes(handle.read(MAX_BYTES + 1))

    @classmethod
    def _from_bytes(cls, data: bytes) -> ActionList:
        if len(data) > MAX_BYTES:
            raise ValueError("action list: over 1 MiB")
        return cls.from_json(json.loads(data.decode("utf-8")))

    def get(self, name: str) -> Action | None:
        return self._actions.get(name)

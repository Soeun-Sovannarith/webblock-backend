"""Request IDs and the W3C ``traceparent`` and ``tracestate`` headers (FR-12).

A request ID is kept when exactly one valid value arrives (``[A-Za-z0-9._:-]{1,128}``); otherwise a
new UUIDv7 is made. A ``traceparent`` is kept, unchanged, only when it is valid: printable ASCII and
at most 512 bytes, lower case hex, version not ``ff``, trace and span IDs not all zero, exactly four
fields for version ``00``, and for a later version any more fields after a ``-``. Any other value
is dropped. The library never starts a trace and never changes the sampled flag."""

from __future__ import annotations

import re
import uuid
from collections.abc import Sequence
from dataclasses import dataclass
from typing import Final

REQUEST_ID: Final = re.compile(r"[A-Za-z0-9._:-]{1,128}", re.ASCII)
MAX_TRACESTATE: Final = 512
MAX_TRACEPARENT: Final = 512

_TRACEPARENT: Final = re.compile(
    r"([0-9a-f]{2})-([0-9a-f]{32})-([0-9a-f]{16})-([0-9a-f]{2})(-[\x20-\x7e]*)?", re.ASCII
)
_TRACESTATE: Final = re.compile(r"[\x20-\x7e]*", re.ASCII)


@dataclass(frozen=True, slots=True)
class TraceParent:
    """A valid ``traceparent``; ``header`` is the value to pass on."""

    version: str
    trace_id: str
    span_id: str
    flags: str
    header: str

    @property
    def sampled(self) -> bool:
        return bool(int(self.flags, 16) & 1)


def parse_traceparent(value: str) -> TraceParent | None:
    """The trace context of ``value``, or None when it is not valid (it is then dropped)."""
    if len(value) > MAX_TRACEPARENT:
        return None
    match = _TRACEPARENT.fullmatch(value)
    if match is None:
        return None
    version, trace_id, span_id, flags, rest = match.groups()
    if version == "ff" or (version == "00" and rest is not None):
        return None
    if trace_id == "0" * 32 or span_id == "0" * 16:
        return None
    return TraceParent(version, trace_id, span_id, flags, value)


def new_request_id() -> str:
    """A new request ID: a UUIDv7 in canonical form."""
    return str(uuid.uuid7())


def request_id_from(values: Sequence[str]) -> str:
    """The incoming request ID when exactly one valid value arrived, else a new one."""
    if len(values) == 1 and REQUEST_ID.fullmatch(values[0]):
        return values[0]
    return new_request_id()


def tracestate_from(values: Sequence[str]) -> str | None:
    """The incoming ``tracestate`` (several headers joined with commas), or None when absent, too
    long or holding a control character."""
    if not values:
        return None
    joined = ",".join(values)
    if len(joined) > MAX_TRACESTATE or _TRACESTATE.fullmatch(joined) is None:
        return None
    return joined

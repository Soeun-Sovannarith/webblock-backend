"""The issuer's key set (FR-2, TR-9), ported from Provisioning's
``infrastructure/identity/jwks.py``.

The ``jwks_uri`` comes from the issuer's discovery document, whose ``issuer`` must equal the
configured one. Nothing is fetched at construction. Each fetch uses httpx2 with no redirect (a 3xx
answer is a failed fetch), no proxy or trust settings from the environment, certificate checks on, a
connect timeout of 2 s, a total of 5 s and a body of at most 1 MiB, read as a stream.

The cache:

- a set younger than 10 minutes is used without a fetch; an older one, an unknown ``kid`` or no set
at all causes a fetch, at most one per 30 s whatever the reason (counted from the previous attempt,
failed or not); concurrent callers wait for the one fetch in flight;
- a fetched set replaces the cached one whole, so a key removed from the set stops working; a failed
fetch changes nothing;
- keys fetched more than 24 hours ago are not used;
- a caller whose ``kid`` is in the usable cached set never waits for a fetch another caller
started;
- the answer: the key; ``UnknownKid`` (401) when the set is usable but lacks the ``kid``;
``IdentityUnavailable`` (503) when nothing usable is cached, or when the fetch this ``kid`` caused
failed.

The discovery document and the key set share one deadline of 5 s. The ``jwks_uri`` must be on the
scheme, host and port of the issuer; after a failed fetch the discovery document is read again. An
answer with a ``Content-Encoding`` other than ``identity`` is a failed fetch.

Nothing here logs a key, a URL, a ``kid`` or a response; a failed fetch logs a fixed cause."""

from __future__ import annotations

import asyncio
import logging
import ssl
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any, Final
from urllib.parse import urlsplit

import httpx2
from cryptography.hazmat.primitives.asymmetric import rsa
from jwt.algorithms import RSAAlgorithm

from webblock_commons.core.token import decode_object

REFRESH_SECONDS: Final = 600.0
MIN_INTERVAL_SECONDS: Final = 30.0
MAX_AGE_SECONDS: Final = 86_400.0
MAX_BYTES: Final = 1024 * 1024
CONNECT_SECONDS: Final = 2.0
TOTAL_SECONDS: Final = 5.0
MIN_RSA_BITS: Final = 2048
MAX_KEYS: Final = 256

PRIVATE_MEMBERS: Final = frozenset({"d", "p", "q", "dp", "dq", "qi", "oth", "k"})
LOG: Final = logging.getLogger("webblock_commons")


class IdentityUnavailable(Exception):
    """No key set recent enough to verify with (503 ``IDENTITY_UNAVAILABLE``)."""


class UnknownKid(Exception):
    """The token names a key the issuer does not publish (401)."""


class InvalidKeySet(Exception):
    """A fetched key set that must not replace the cached one."""


class _FetchFailed(Exception):
    def __init__(self, cause: str) -> None:
        super().__init__(cause)
        self.cause = cause


@dataclass(frozen=True, slots=True)
class _KeySet:
    keys: dict[str, rsa.RSAPublicKey]
    fetched_at: float


def https_url(value: object) -> str | None:
    """``value`` when it is an absolute https URL with a host and no credentials, else None."""
    if not isinstance(value, str):
        return None
    parts = urlsplit(value)
    if parts.scheme != "https" or not parts.hostname or parts.username or parts.password:
        return None
    return value


def same_origin(one: str, two: str) -> bool:
    """Whether two https URLs share scheme, host (any case) and port (443 when none)."""
    first, second = urlsplit(one), urlsplit(two)
    return (
        first.scheme == second.scheme
        and (first.hostname or "") == (second.hostname or "")
        and (first.port or 443) == (second.port or 443)
    )


def parse_jwks(body: bytes) -> dict[str, rsa.RSAPublicKey]:
    """The usable RSA keys of a key set by key ID; ``InvalidKeySet`` when the set must not be used.

    Keys this library does not use are skipped (another key type, ``use`` other than ``sig``, an
    ``alg`` other than ``RS256``, ``key_ops`` without ``verify``, no key ID or one with a control
    character (U+0000 to U+001F, U+007F to U+009F), under 2048 bits). A set holding private key
    material, repeating a key ID or holding an RSA key that does not parse is refused whole, and so
    is a set with no usable key left, or one nested deeper than 16 levels."""
    doc = decode_object(body)
    items = doc.get("keys") if doc is not None else None
    if not isinstance(items, list) or not 0 < len(items) <= MAX_KEYS:
        raise InvalidKeySet("no keys")
    out: dict[str, rsa.RSAPublicKey] = {}
    seen: set[object] = set()
    for item in items:
        if not isinstance(item, dict):
            raise InvalidKeySet("a key is not an object")
        if PRIVATE_MEMBERS & item.keys():
            raise InvalidKeySet("private key material")
        kid = item.get("kid")
        if kid in seen and kid is not None:
            raise InvalidKeySet("repeated key ID")
        seen.add(kid)
        if item.get("kty") != "RSA" or not _usable_for_rs256(item):
            continue
        key = _rsa_key(item)
        if isinstance(kid, str) and kid and not _has_control(kid) and key.key_size >= MIN_RSA_BITS:
            out[kid] = key
    if not out:
        raise InvalidKeySet("no usable key")
    return out


def _has_control(text: str) -> bool:
    """Whether ``text`` holds a control character (U+0000 to U+001F, U+007F to U+009F)."""
    return any(ord(char) < 0x20 or 0x7F <= ord(char) <= 0x9F for char in text)


def _usable_for_rs256(item: dict[str, Any]) -> bool:
    ops = item.get("key_ops")
    return (
        item.get("use", "sig") == "sig"
        and item.get("alg", "RS256") == "RS256"
        and (ops is None or (isinstance(ops, list) and "verify" in ops))
    )


def _rsa_key(item: dict[str, Any]) -> rsa.RSAPublicKey:
    try:
        key: object = RSAAlgorithm.from_jwk(item)
    except Exception:  # any parse failure refuses the whole set
        raise InvalidKeySet("a key does not parse") from None
    if not isinstance(key, rsa.RSAPublicKey):
        raise InvalidKeySet("not a public key")
    return key


class KeySetSource:
    """The issuer's current key set. Use it from one event loop."""

    __slots__ = (
        "_clock",
        "_inflight",
        "_issuer",
        "_jwks_uri",
        "_last_attempt",
        "_set",
        "_ssl",
        "_total",
        "_transport",
    )

    def __init__(
        self,
        issuer: str,
        *,
        clock: Callable[[], float],
        transport: httpx2.AsyncBaseTransport | None = None,
        ssl_context: ssl.SSLContext | None = None,
        total_timeout: float = TOTAL_SECONDS,
    ) -> None:
        """Fetches nothing. ``transport`` and ``ssl_context`` are for tests only: a service never
        passes them, since they replace the network and its certificate checks."""
        if https_url(issuer) is None:
            raise ValueError("identity: issuer must be an absolute https URL")
        self._issuer = issuer
        self._clock = clock
        self._transport = transport
        self._ssl = ssl_context
        self._total = total_timeout
        self._jwks_uri: str | None = None
        self._set: _KeySet | None = None
        self._last_attempt: float | None = None
        self._inflight: asyncio.Task[bool] | None = None

    def __repr__(self) -> str:
        return f"KeySetSource(issuer={self._issuer!r})"

    def _usable(self, now: float) -> _KeySet | None:
        if self._set is None or now - self._set.fetched_at > MAX_AGE_SECONDS:
            return None
        return self._set

    async def key(self, kid: str) -> rsa.RSAPublicKey:
        """The key of ``kid``: ``UnknownKid`` or ``IdentityUnavailable`` otherwise."""
        current = self._usable(self._clock())
        if current is not None and kid in current.keys:
            fresh = self._clock() - current.fetched_at < REFRESH_SECONDS
            if fresh or self._inflight is not None:
                return current.keys[kid]
        fetched = await self._fetch_if_allowed()
        current = self._usable(self._clock())
        if current is None:
            raise IdentityUnavailable("no key set recent enough")
        if kid in current.keys:
            return current.keys[kid]
        if fetched is False:
            raise IdentityUnavailable("the refetch failed")
        raise UnknownKid

    async def _fetch_if_allowed(self) -> bool | None:
        """Waits for the fetch in flight or starts one, unless the last attempt was less than 30 s
        ago. True or False is the outcome of the fetch waited for; None when none was allowed."""
        task = self._inflight
        if task is None:
            now = self._clock()
            if self._last_attempt is not None and now - self._last_attempt < MIN_INTERVAL_SECONDS:
                return None
            self._last_attempt = now
            task = asyncio.get_running_loop().create_task(self._fetch_and_store())
            self._inflight = task
            task.add_done_callback(self._fetched)
        return await asyncio.shield(task)

    def _fetched(self, task: asyncio.Task[bool]) -> None:
        if self._inflight is task:
            self._inflight = None

    async def _fetch_and_store(self) -> bool:
        try:
            async with asyncio.timeout(self._total):
                keys = parse_jwks(await self._get(await self._key_set_url()))
        except _FetchFailed as failed:
            cause = failed.cause
        except InvalidKeySet:
            cause = "jwks_invalid"
        except TimeoutError:
            cause = "jwks_timeout"
        except Exception as exc:  # a transport failure of any kind: logged by class only
            cause = f"jwks_transport:{type(exc).__name__}"
        else:
            self._set = _KeySet(keys=keys, fetched_at=self._clock())
            return True
        LOG.warning("key set fetch failed", extra={"auth_cause": cause})
        self._jwks_uri = None
        return False

    async def _key_set_url(self) -> str:
        if self._jwks_uri is None:
            body = await self._get(self._issuer + "/.well-known/openid-configuration")
            doc = decode_object(body)
            if doc is None or doc.get("issuer") != self._issuer:
                raise _FetchFailed("discovery_issuer")
            uri = https_url(doc.get("jwks_uri"))
            if uri is None or not same_origin(uri, self._issuer):
                raise _FetchFailed("discovery_jwks_uri")
            self._jwks_uri = uri
        return self._jwks_uri

    async def _get(self, url: str) -> bytes:
        timeout = httpx2.Timeout(self._total, connect=CONNECT_SECONDS)
        async with (
            httpx2.AsyncClient(
                transport=self._transport,
                verify=self._ssl if self._ssl is not None else True,
                trust_env=False,
                follow_redirects=False,
                timeout=timeout,
            ) as client,
            client.stream(
                "GET", url, headers={"Accept": "application/json", "Accept-Encoding": "identity"}
            ) as response,
        ):
            if response.status_code != 200:
                raise _FetchFailed("fetch_status")
            if response.headers.get("content-encoding", "identity").lower() != "identity":
                raise _FetchFailed("fetch_encoding")
            length = response.headers.get("content-length")
            if length is not None and (not length.isdigit() or int(length) > MAX_BYTES):
                raise _FetchFailed("fetch_too_large")
            body = bytearray()
            async for chunk in response.aiter_bytes():
                body += chunk
                if len(body) > MAX_BYTES:
                    raise _FetchFailed("fetch_too_large")
            return bytes(body)

"""The framework-free core of webblock_commons (TR-3): it imports no web, gRPC or messaging
framework."""

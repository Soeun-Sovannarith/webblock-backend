"""The token check (FR-1, FR-2, FR-3), ported from Provisioning's
``infrastructure/identity/verifier.py``.

``TokenVerifier.user`` takes the ``Authorization`` header values and returns the ``WebBlockUser``,
or raises ``WebBlockProblem``: ``UNAUTHENTICATED`` for every refused token whatever the cause (never
500), ``IDENTITY_UNAVAILABLE`` when no key set can be had, ``ACCESS_DENIED`` for a bad ``user_id``.
The cause goes to a DEBUG log line as a fixed word, never with the token, a claim or the ``kid``."""

from __future__ import annotations

import logging
import ssl
import time
from collections.abc import Callable, Sequence
from typing import Any, Final

import httpx2
import jwt

from webblock_commons.core import errors
from webblock_commons.core.errors import WebBlockProblem
from webblock_commons.core.keyset import IdentityUnavailable, KeySetSource, UnknownKid
from webblock_commons.core.settings import Settings
from webblock_commons.core.token import (
    ALGORITHM,
    Refusal,
    bearer_token,
    check_claims,
    decode_object,
    parse_header,
    split_token,
)
from webblock_commons.core.user import WebBlockUser, user_from_claims

LOG: Final = logging.getLogger("webblock_commons")


class TokenVerifier:
    """Checks bearer tokens against the issuer's key set. One per process, one event loop."""

    __slots__ = ("_audience", "_clock", "_issuer", "_jws", "_keys")

    def __init__(
        self,
        settings: Settings,
        *,
        clock: Callable[[], float] = time.time,
        transport: httpx2.AsyncBaseTransport | None = None,
        ssl_context: ssl.SSLContext | None = None,
    ) -> None:
        """Fetches nothing. ``transport`` and ``ssl_context`` are for tests only: a service never
        passes them, since they replace the network and its certificate checks."""
        self._issuer = settings.issuer
        self._audience = settings.audience
        self._clock = clock
        self._jws = jwt.PyJWS(
            algorithms=[ALGORITHM],
            options={"verify_signature": True, "enforce_minimum_key_length": True},
        )
        self._keys = KeySetSource(
            settings.issuer, clock=clock, transport=transport, ssl_context=ssl_context
        )

    def __repr__(self) -> str:
        return f"TokenVerifier(issuer={self._issuer!r}, audience={self._audience!r})"

    async def user(self, authorization: Sequence[str]) -> WebBlockUser:
        """The user of the request whose ``Authorization`` header values are ``authorization``."""
        return user_from_claims(await self.claims(authorization))

    async def claims(self, authorization: Sequence[str]) -> dict[str, Any]:
        """The verified claims; ``WebBlockProblem`` otherwise."""
        try:
            return await self._verify(bearer_token(authorization))
        except IdentityUnavailable:
            raise WebBlockProblem(errors.IDENTITY_UNAVAILABLE) from None
        except Refusal as refusal:
            cause = refusal.cause
        except Exception as exc:  # anything unexpected refuses, logged by class
            cause = f"internal:{type(exc).__name__}"
        LOG.debug("token refused", extra={"auth_cause": cause})
        raise WebBlockProblem(errors.UNAUTHENTICATED) from None

    async def _verify(self, raw: str) -> dict[str, Any]:
        header_segment, _, _ = split_token(raw)
        header = parse_header(header_segment)
        try:
            key = await self._keys.key(header.kid)
        except UnknownKid:
            raise Refusal("unknown_kid") from None
        try:
            decoded = self._jws.decode_complete(raw, key, algorithms=[ALGORITHM])
        except jwt.InvalidSignatureError:
            raise Refusal("bad_signature") from None
        except jwt.PyJWTError:
            raise Refusal("token_format") from None
        payload: Any = decoded["payload"]
        claims = decode_object(payload) if isinstance(payload, bytes) else None
        if claims is None:
            raise Refusal("claims_malformed")
        check_claims(claims, issuer=self._issuer, audience=self._audience, now=self._clock())
        return claims

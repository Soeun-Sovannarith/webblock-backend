"""The library's settings (TR-8), given by the service. Building them checks every value."""

from __future__ import annotations

import logging
import re
from collections.abc import Collection, Mapping
from dataclasses import dataclass, field
from types import MappingProxyType
from typing import Final

from webblock_commons.core.keyset import https_url

_SERVICE: Final = re.compile(r"[a-z0-9][a-z0-9-]*", re.ASCII)
PRINCIPAL: Final = re.compile(r"[a-z0-9.-]+/ns/[a-z0-9-]+/sa/[a-z0-9-]+", re.ASCII)
_GRPC_KEY: Final = re.compile(r"/?[A-Za-z0-9_.]+\.[A-Za-z0-9_]+/[A-Za-z0-9_]+", re.ASCII)
_REST_KEY: Final = re.compile(r"([A-Za-z]+)\s+(/\S*)", re.ASCII)
LOG: Final = logging.getLogger("webblock_commons")
LOCAL_PROFILES: Final = frozenset({"prototype", "local", "test"})
"""The profiles on which dev mode may start (FR-8), compared exactly."""


@dataclass(frozen=True, slots=True)
class Settings:
    """``issuer``: the realm URL, compared exactly with ``iss``. ``audience``: this service's
    audience. ``service_name``: the gRPC ``ErrorInfo`` domain is ``<service_name>.webblock``.
    ``allowed_callers``: for each internal method (a gRPC full method name such as
    ``/webblock.project.v1.AccessService/CheckAccess``, or ``<HTTP method> <path template>`` such as
    ``POST /internal/v1/projects/{project_id}``) the whole principals that may call it; a method
    with no entry allows nobody; a REST key's method may be in any case, with any whitespace
    around or between its two parts; a gRPC key without its leading ``/`` gets one; a key of
    neither shape is a warning; two keys that are the same once normalised, or a principal that
    is not whole, stop start-up. ``dev_mode``: take the caller from ``X-Webblock-Dev-Caller``; it
    starts only when ``profiles`` (the service's active profiles) is not empty and every profile
    is a local profile."""

    issuer: str
    audience: str
    service_name: str
    allowed_callers: Mapping[str, Collection[str]] = field(default_factory=dict)
    dev_mode: bool = False
    profiles: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        if https_url(self.issuer) is None:
            raise ValueError("webblock_commons: issuer must be an absolute https URL")
        if not self.audience:
            raise ValueError("webblock_commons: audience is required")
        if _SERVICE.fullmatch(self.service_name) is None:
            raise ValueError("webblock_commons: service_name must be lower case letters, digits, -")
        _check_dev_mode(self.dev_mode, self.profiles)
        object.__setattr__(
            self, "allowed_callers", MappingProxyType(_callers(self.allowed_callers))
        )
        if self.dev_mode:
            LOG.warning("dev mode is on: the caller of an internal method is read from the header")

    @property
    def domain(self) -> str:
        """The gRPC ``ErrorInfo`` domain."""
        return f"{self.service_name}.webblock"


def _check_dev_mode(dev_mode: bool, profiles: tuple[str, ...]) -> None:
    """Dev mode starts only when every active profile is a local profile and there is one."""
    if dev_mode and (not profiles or not all(p in LOCAL_PROFILES for p in profiles)):
        raise ValueError(
            "webblock_commons: dev_mode is on but the active profiles are not all local "
            f"profiles ({', '.join(sorted(LOCAL_PROFILES))}); a missing profile counts as "
            "production"
        )


def normalise_key(method: str) -> str:
    """An allowed-callers key as it is compared: ``METHOD /path`` with the method in upper case
    and one space, or a gRPC full method name with its leading ``/``."""
    key = method.strip()
    rest = _REST_KEY.fullmatch(key)
    if rest is not None:
        return f"{rest.group(1).upper()} {rest.group(2)}"
    if _GRPC_KEY.fullmatch(key) is not None and not key.startswith("/"):
        return "/" + key
    return key


def _callers(allowed_callers: Mapping[str, Collection[str]]) -> dict[str, frozenset[str]]:
    """The allowed callers by normalised key; ``ValueError`` for a malformed entry, a principal
    that is not whole, or a key that repeats once normalised."""
    callers: dict[str, frozenset[str]] = {}
    for method, principals in allowed_callers.items():
        if not method or isinstance(principals, str):
            raise ValueError("webblock_commons: allowed_callers needs a method and a list")
        if not all(isinstance(p, str) and PRINCIPAL.fullmatch(p) for p in principals):
            raise ValueError(
                "webblock_commons: allowed_callers holds a value that is not a whole "
                "principal <trust domain>/ns/<namespace>/sa/<service account>"
            )
        key = normalise_key(method)
        if key in callers:
            raise ValueError(f"webblock_commons: allowed_callers names the method {key} twice")
        if _GRPC_KEY.fullmatch(key) is None and _REST_KEY.fullmatch(key) is None:
            LOG.warning(
                "an allowed_callers key is neither a gRPC method nor METHOD /path",
                extra={"method": key},
            )
        callers[key] = frozenset(principals)
    return callers

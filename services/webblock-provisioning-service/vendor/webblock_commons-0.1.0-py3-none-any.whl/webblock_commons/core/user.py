"""The current user (FR-3) and the first two one-liners, signed-in and admins only (FR-4).

``user_id`` is a canonical lowercase, non-nil UUID string with nothing before or after it. ``roles``
comes from the top-level ``roles`` claim only, as a list of text; anything else gives no roles.
``is_admin`` is ``ADMIN`` in roles, compared whole and with case. An inner user (from ``x-user-id``)
has no roles."""

from __future__ import annotations

import re
import uuid
from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any, Final

from webblock_commons.core import context, errors
from webblock_commons.core.errors import WebBlockProblem

ADMIN: Final = "ADMIN"
_UUID: Final = re.compile(r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}", re.ASCII)
_NIL: Final = "00000000-0000-0000-0000-000000000000"


@dataclass(frozen=True, slots=True)
class WebBlockUser:
    """The user a request acts for. Holds no token."""

    user_id: uuid.UUID
    roles: tuple[str, ...] = ()

    @property
    def is_admin(self) -> bool:
        return ADMIN in self.roles


def parse_user_id(value: object) -> uuid.UUID | None:
    """The user ID of ``value`` when it is a canonical lowercase, non-nil UUID string; else None."""
    if not isinstance(value, str) or value == _NIL or _UUID.fullmatch(value) is None:
        return None
    return uuid.UUID(value)


def roles_from(value: object) -> tuple[str, ...]:
    """The ``roles`` claim when it is a list of text; else no roles."""
    if isinstance(value, list) and all(isinstance(item, str) for item in value):
        return tuple(value)
    return ()


def user_from_claims(claims: Mapping[str, Any]) -> WebBlockUser:
    """The user of verified claims; ``ACCESS_DENIED`` when ``user_id`` is not valid."""
    user_id = parse_user_id(claims.get("user_id"))
    if user_id is None:
        raise WebBlockProblem(errors.ACCESS_DENIED)
    return WebBlockUser(user_id=user_id, roles=roles_from(claims.get("roles")))


def current_user() -> WebBlockUser:
    """The signed-in one-liner: the current user; 403 when there is a caller and no user (an inner
    call without ``x-user-id``, or work with a caller); 401 when there is neither (a request with
    no token, a message consumer)."""
    ctx = context.current()
    if ctx is not None and ctx.user is not None:
        return ctx.user
    if ctx is not None and ctx.caller is not None:
        raise WebBlockProblem(errors.ACCESS_DENIED)
    raise WebBlockProblem(errors.UNAUTHENTICATED)


def require_admin() -> WebBlockUser:
    """The admins-only one-liner: the current user when ``ADMIN`` is in the token's roles; 403
    otherwise."""
    user = current_user()
    if not user.is_admin:
        raise WebBlockProblem(errors.ACCESS_DENIED)
    return user

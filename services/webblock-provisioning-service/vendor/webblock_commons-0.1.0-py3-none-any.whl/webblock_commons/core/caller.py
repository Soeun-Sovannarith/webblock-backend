"""Inner calls (FR-7, FR-8): the caller from ``X-Forwarded-Client-Cert``, the allowed-callers
check, the inner user from ``x-user-id``, and the system context for work with no user.

The parser follows "Caller from X-Forwarded-Client-Cert" of REQUIREMENTS.md: one header line only;
elements split on commas outside quotes and only the last one counts; pairs split on ``;`` outside
quotes with exact keys; ``\\`` escapes inside quotes and makes the header malformed outside them;
exactly one ``URI`` key whose value starts with ``spiffe://``; the rest must be a whole principal
``<trust domain>/ns/<namespace>/sa/<service account>``."""

from __future__ import annotations

from collections.abc import Iterator, Sequence
from contextlib import contextmanager
from dataclasses import dataclass
from typing import Final

from webblock_commons.core import context, errors
from webblock_commons.core.errors import WebBlockProblem
from webblock_commons.core.settings import PRINCIPAL, Settings
from webblock_commons.core.traceparent import new_request_id
from webblock_commons.core.user import WebBlockUser, parse_user_id

SPIFFE: Final = "spiffe://"
_QUOTED_KEY: Final = "\x00"


@dataclass(frozen=True, slots=True)
class Caller:
    """The calling service's mTLS principal, ``cluster.local/ns/<ns>/sa/<name>``."""

    principal: str

    def __repr__(self) -> str:
        return f"Caller({self.principal!r})"


def _elements(header: str) -> list[list[tuple[str, str]]] | None:
    """The elements of a header, each a list of (key, value) pairs; None when malformed."""
    elements: list[list[tuple[str, str]]] = []
    pairs: list[tuple[str, str]] = []
    text: list[str] = []
    key: str | None = None
    quoted_key = in_quote = False
    index = 0
    while index < len(header):
        char = header[index]
        index += 1
        if in_quote:
            if char == "\\":
                if index >= len(header):
                    return None
                text.append(header[index])
                index += 1
            elif char == '"':
                in_quote = False
            else:
                text.append(char)
        elif char == '"':
            in_quote = True
            quoted_key = quoted_key or key is None
        elif char == "\\":
            return None
        elif char == "=" and key is None:
            key = _QUOTED_KEY if quoted_key else "".join(text)
            text = []
        elif char in ";,":
            pairs.append((key if key is not None else _QUOTED_KEY, "".join(text)))
            key, text, quoted_key = None, [], False
            if char == ",":
                elements.append(pairs)
                pairs = []
        else:
            text.append(char)
    if in_quote:
        return None
    pairs.append((key if key is not None else _QUOTED_KEY, "".join(text)))
    elements.append(pairs)
    return elements


def caller_from_xfcc(values: Sequence[str]) -> str | None:
    """The caller principal of the ``X-Forwarded-Client-Cert`` header values, or None."""
    if len(values) != 1:
        return None
    elements = _elements(values[0])
    if not elements:
        return None
    uris = [value for key, value in elements[-1] if key == "URI"]
    if len(uris) != 1 or not uris[0].startswith(SPIFFE):
        return None
    principal = uris[0].removeprefix(SPIFFE)
    return principal if PRINCIPAL.fullmatch(principal) else None


def _dev_caller(values: Sequence[str]) -> str | None:
    if len(values) != 1 or PRINCIPAL.fullmatch(values[0]) is None:
        return None
    return values[0]


def inner_call(
    settings: Settings,
    method: str,
    *,
    xfcc: Sequence[str],
    dev_caller: Sequence[str],
    user_id: Sequence[str],
) -> tuple[Caller, WebBlockUser | None]:
    """The caller and the inner user of a call to internal ``method`` (a gRPC full method name or
    ``<HTTP method> <path template>``). 401 without a caller; 403 when the caller is not on the
    method's list (a method with no list allows nobody) or ``x-user-id`` is not exactly one
    canonical UUID. Never reads ``Authorization``. The inner user has no roles."""
    principal = _dev_caller(dev_caller) if settings.dev_mode else caller_from_xfcc(xfcc)
    if principal is None:
        raise WebBlockProblem(errors.UNAUTHENTICATED)
    if principal not in settings.allowed_callers.get(method, frozenset()):
        raise WebBlockProblem(errors.ACCESS_DENIED)
    if not user_id:
        return Caller(principal), None
    parsed = parse_user_id(user_id[0]) if len(user_id) == 1 else None
    if parsed is None:
        raise WebBlockProblem(errors.ACCESS_DENIED)
    return Caller(principal), WebBlockUser(user_id=parsed)


@contextmanager
def system_context(caller: Caller | None = None) -> Iterator[context.RequestContext]:
    """A context with no user for background work (consumers, workers): the given caller, and the
    request ID and trace of the work in progress when there is one, else a new request ID and no
    trace (FR-7). The signed-in one-liner answers 403 inside it with a caller, 401 without."""
    current = context.current()
    ctx = context.RequestContext(
        request_id=current.request_id if current else new_request_id(),
        traceparent=current.traceparent if current else None,
        tracestate=current.tracestate if current else None,
        caller=caller,
        system=True,
    )
    with context.bound(ctx):
        yield ctx

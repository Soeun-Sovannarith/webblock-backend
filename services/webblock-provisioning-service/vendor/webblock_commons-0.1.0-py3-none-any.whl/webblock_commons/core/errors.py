"""Error codes and the problem document (FR-10, FR-11).

``WebBlockProblem`` is the one exception the library raises for a refusal; it carries an
``ErrorCode`` (code, HTTP status, title) and says nothing else, so no token or caller input can
reach an answer or a log through it. The codes and titles equal ``testcases/errors/codes.json``. A
service passes its own not-found codes as ``ErrorCode.not_found(code, title)``."""

from __future__ import annotations

import re
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from typing import Any, Final

# HTTP status to gRPC status name (Notion "Web Block architecture" 2.3; 409 as FAILED_PRECONDITION).
GRPC_STATUS: Final[Mapping[int, str]] = {
    400: "INVALID_ARGUMENT",
    401: "UNAUTHENTICATED",
    403: "PERMISSION_DENIED",
    404: "NOT_FOUND",
    409: "FAILED_PRECONDITION",
    500: "INTERNAL",
    503: "UNAVAILABLE",
}
PROBLEM_JSON: Final = "application/problem+json"
JSON: Final = "application/json"

_CODE: Final = re.compile(r"[A-Z][A-Z0-9_]*", re.ASCII)


@dataclass(frozen=True, slots=True)
class ErrorCode:
    """One error code, its HTTP status and its title."""

    code: str
    status: int
    title: str

    def __post_init__(self) -> None:
        if _CODE.fullmatch(self.code) is None:
            raise ValueError("error code: code must be upper case letters, digits and _")
        if self.status not in GRPC_STATUS:
            raise ValueError(f"error code: status must be one of {sorted(GRPC_STATUS)}")
        if not self.title:
            raise ValueError("error code: title is required")

    @classmethod
    def not_found(cls, code: str, title: str) -> ErrorCode:
        """A service's not-found code, for example ``BILL_NOT_FOUND``."""
        return cls(code, 404, title)

    @property
    def type(self) -> str:
        """The problem ``type``: ``urn:webblock:problem:`` and the code, lower case with dashes."""
        return "urn:webblock:problem:" + self.code.lower().replace("_", "-")

    @property
    def grpc_status(self) -> str:
        """The gRPC status name of ARCH 2.3."""
        return GRPC_STATUS[self.status]


UNAUTHENTICATED: Final = ErrorCode("UNAUTHENTICATED", 401, "Authentication is required.")
ACCESS_DENIED: Final = ErrorCode(
    "ACCESS_DENIED", 403, "You are not allowed to perform this action."
)
PROJECT_NOT_FOUND: Final = ErrorCode.not_found(
    "PROJECT_NOT_FOUND", "No project with this ID was found."
)
PROJECT_DELETED: Final = ErrorCode("PROJECT_DELETED", 409, "This project was deleted.")
PROJECT_SUSPENDED: Final = ErrorCode("PROJECT_SUSPENDED", 409, "This project is suspended.")
INTERNAL_ERROR: Final = ErrorCode("INTERNAL_ERROR", 500, "An unexpected error occurred.")
IDENTITY_UNAVAILABLE: Final = ErrorCode(
    "IDENTITY_UNAVAILABLE", 503, "Your sign-in could not be checked. Try again later."
)
ACCESS_UNAVAILABLE: Final = ErrorCode(
    "ACCESS_UNAVAILABLE", 503, "Access could not be checked. Try again later."
)
COMMONS_CODES: Final = (
    UNAUTHENTICATED,
    ACCESS_DENIED,
    PROJECT_NOT_FOUND,
    PROJECT_DELETED,
    PROJECT_SUSPENDED,
    INTERNAL_ERROR,
    IDENTITY_UNAVAILABLE,
    ACCESS_UNAVAILABLE,
)


class WebBlockProblem(Exception):
    """A refusal with its error code. Its message and ``repr`` are the code only."""

    def __init__(self, error: ErrorCode) -> None:
        super().__init__(error.code)
        self.error = error

    def __repr__(self) -> str:
        return f"WebBlockProblem({self.error.code!r})"


def problem_body(
    error: ErrorCode, *, instance: str, request_id: str, trace_id: str | None
) -> dict[str, Any]:
    """The RFC 9457 problem of FR-10: no ``detail``; ``traceId`` only for a traced request."""
    body: dict[str, Any] = {
        "type": error.type,
        "title": error.title,
        "status": error.status,
        "instance": instance,
        "code": error.code,
        "requestId": request_id,
    }
    if trace_id is not None:
        body["traceId"] = trace_id
    body["errors"] = []
    return body


def problem_media_type(accept: Sequence[str]) -> str:
    """``application/json`` when the client accepts only that, else ``application/problem+json``."""
    types = {
        part.split(";")[0].strip().lower() for value in accept for part in value.split(",")
    } - {""}
    if JSON in types and not types & {PROBLEM_JSON, "application/*", "*/*"}:
        return JSON
    return PROBLEM_JSON

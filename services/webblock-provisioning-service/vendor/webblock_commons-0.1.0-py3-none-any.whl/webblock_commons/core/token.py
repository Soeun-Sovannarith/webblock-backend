"""The shape, header and claims of a bearer token (FR-1), ported from Provisioning's
``infrastructure/identity/token.py``.

pyjwt checks the signature only (``verifier.py``). Everything else is here: the ``Authorization``
header, the size, the alphabet and the three parts, the JSON (no repeated member, no NaN, at most
16 levels deep, the outer object counted), the forbidden headers, ``alg`` exactly ``RS256``, a
``kid`` of text, and every claim. A refusal is ``Refusal`` with a fixed cause for the log; it
never carries a token, a claim value or a ``kid``."""

from __future__ import annotations

import base64
import binascii
import json
import math
import re
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from typing import Any, Final

MAX_TOKEN_BYTES: Final = 8192
MAX_HEADER_BYTES: Final = 512
MAX_HEADER_MEMBERS: Final = 16
MAX_KID_BYTES: Final = 256
MAX_JSON_DEPTH: Final = 16
CLOCK_SKEW_SECONDS: Final = 30.0
ALGORITHM: Final = "RS256"

FORBIDDEN_HEADERS: Final = ("jku", "jwk", "x5u", "x5c", "crit", "zip", "enc")
"""Headers that name where a key would come from or change how the token is processed."""

_BEARER: Final = re.compile(r"[Bb][Ee][Aa][Rr][Ee][Rr] +([^ ]+)", re.ASCII)
_TOKEN: Final = re.compile(r"[A-Za-z0-9_.-]+", re.ASCII)


class Refusal(Exception):
    """A refused token, with a fixed ``cause`` for the log (never a value)."""

    def __init__(self, cause: str) -> None:
        super().__init__(cause)
        self.cause = cause


@dataclass(frozen=True, slots=True)
class Header:
    """What the verifier needs of a token's protected header."""

    kid: str


def bearer_token(values: Sequence[str]) -> str:
    """The token of the ``Authorization`` header values: exactly one value, scheme ``Bearer`` in any
    case, one token."""
    if len(values) != 1:
        raise Refusal("authorization_count")
    match = _BEARER.fullmatch(values[0])
    if match is None:
        raise Refusal("authorization_scheme")
    return match.group(1)


def split_token(raw: str) -> tuple[str, str, str]:
    """The three parts of a compact JWS after the outer checks: at most 8 KiB, the base64url
    alphabet and dots only, exactly three non-empty parts."""
    if len(raw) > MAX_TOKEN_BYTES:
        raise Refusal("token_size")
    if not raw or _TOKEN.fullmatch(raw) is None:
        raise Refusal("token_format")
    parts = raw.split(".")
    if len(parts) != 3 or not all(parts):
        raise Refusal("token_format")
    return parts[0], parts[1], parts[2]


def b64url_decode(segment: str) -> bytes | None:
    """Strict base64url without padding; None for anything that does not decode to itself."""
    if len(segment) % 4 == 1:
        return None
    try:
        data = base64.urlsafe_b64decode(segment + "=" * (-len(segment) % 4))
    except binascii.Error, ValueError:
        return None
    if base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii") != segment:
        return None
    return data


def _no_repeats(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for key, value in pairs:
        if key in out:
            raise ValueError("repeated member")
        out[key] = value
    return out


def _no_constant(_name: str) -> Any:
    raise ValueError("not a JSON number")


def _shallow(text: str) -> bool:
    """Whether the JSON text nests at most ``MAX_JSON_DEPTH`` levels (strings skipped)."""
    depth = 0
    in_string = escaped = False
    for char in text:
        if in_string:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == '"':
                in_string = False
        elif char == '"':
            in_string = True
        elif char in "[{":
            depth += 1
            if depth > MAX_JSON_DEPTH:
                return False
        elif char in "]}":
            depth -= 1
    return True


def decode_object(data: bytes) -> dict[str, Any] | None:
    """A JSON object of UTF-8 text; None for anything else, a repeated member, NaN or Infinity,
    trailing data, or nesting deeper than 16 levels (the outer object is level 1)."""
    try:
        text = data.decode("utf-8")
        if not _shallow(text):
            return None
        doc = json.loads(text, object_pairs_hook=_no_repeats, parse_constant=_no_constant)
    except UnicodeDecodeError, ValueError, RecursionError:
        return None
    return doc if isinstance(doc, dict) else None


def parse_header(segment: str) -> Header:
    """The protected header: at most 512 bytes once decoded (checked before it is parsed) and at
    most 16 members, no forbidden member, ``alg`` exactly ``RS256``, a ``kid`` of 1 to 256
    bytes of text. A ``kid`` with a line break or another control character is never in the key
    set (``keyset.parse_jwks`` skips such keys), so it ends as an unknown key; never logged."""
    if len(segment) > (MAX_HEADER_BYTES * 4 + 2) // 3:
        raise Refusal("header_malformed")
    raw = b64url_decode(segment)
    if raw is None or len(raw) > MAX_HEADER_BYTES:
        raise Refusal("header_malformed")
    header = decode_object(raw)
    if header is None or len(header) > MAX_HEADER_MEMBERS:
        raise Refusal("header_malformed")
    if any(name in header for name in FORBIDDEN_HEADERS):
        raise Refusal("forbidden_header")
    if header.get("alg") != ALGORITHM:
        raise Refusal("alg_not_allowed")
    kid = header.get("kid")
    if (
        not isinstance(kid, str)
        or not kid
        or len(kid.encode("utf-8", "surrogatepass")) > MAX_KID_BYTES
    ):
        raise Refusal("kid_invalid")
    return Header(kid=kid)


def numeric_date(claims: Mapping[str, Any], name: str) -> float | None:
    """The NumericDate ``name``; None when absent; ``Refusal`` when it is not a finite number."""
    if name not in claims:
        return None
    value = claims[name]
    if isinstance(value, bool) or not isinstance(value, int | float):
        raise Refusal("claims_malformed")
    number = float(value)
    if not math.isfinite(number):
        raise Refusal("claims_malformed")
    return number


def audience_contains(value: object, want: str) -> bool:
    """Whether ``aud`` (text, or a list of text only) holds ``want`` as a whole element."""
    if isinstance(value, str):
        return value == want
    if isinstance(value, list) and all(isinstance(item, str) for item in value):
        return want in value
    return False


def check_claims(claims: Mapping[str, Any], *, issuer: str, audience: str, now: float) -> None:
    """The claims of FR-1: ``iss`` equal, ``aud`` holding the audience, ``typ`` ``Bearer``,
    ``exp`` required, and ``exp`` and ``nbf`` within the clock skew (30 s included)."""
    iss = claims.get("iss")
    if not isinstance(iss, str) or iss != issuer:
        raise Refusal("issuer_mismatch")
    if not audience_contains(claims.get("aud"), audience):
        raise Refusal("audience_mismatch")
    if claims.get("typ") != "Bearer":
        raise Refusal("typ_mismatch")
    exp = numeric_date(claims, "exp")
    if exp is None:
        raise Refusal("exp_missing")
    if now > exp + CLOCK_SKEW_SECONDS:
        raise Refusal("expired")
    nbf = numeric_date(claims, "nbf")
    if nbf is not None and now + CLOCK_SKEW_SECONDS < nbf:
        raise Refusal("not_yet_valid")

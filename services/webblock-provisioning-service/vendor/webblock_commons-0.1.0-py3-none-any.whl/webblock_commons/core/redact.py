"""The last guard of the log output (FR-15): the whole value of an ``Authorization`` or
``Proxy-Authorization``, of any scheme, every ``Bearer`` value and any text shaped like a JWT
becomes ``[REDACTED]``. The library never logs a token; this catches a service's mistake. Opaque
secrets anywhere else (a cookie, an API key header) are not recognised.

It runs in linear time: a text over 64 KiB is first cut to 64 KiB and ends with ``[TRUNCATED]``,
and the JWT search looks at each run of base64url characters once."""

from __future__ import annotations

import re
from typing import Final

REDACTED: Final = "[REDACTED]"
TRUNCATED: Final = "[TRUNCATED]"
MAX_LENGTH: Final = 64 * 1024

# The name, then ":" or "="; a quoted value runs to its closing quote, any other to the line end.
_AUTHORIZATION: Final = re.compile(
    r"(?i)\b((?:proxy-)?authorization[\"']?\s*[:=]\s*)(?:(\")[^\"\r\n]*|(')[^'\r\n]*|[^\r\n]+)"
)
_BEARER: Final = re.compile(r"(?i)\b(bearer)\s+(?!\[REDACTED\])[^\s\"',;]+")
# A run of base64url characters and dots.
_RUN: Final = re.compile(r"[A-Za-z0-9_.-]*", re.ASCII)


def _authorization(match: re.Match[str]) -> str:
    return f"{match.group(1)}{match.group(2) or ''}{match.group(3) or ''}{REDACTED}"


def _jwts(text: str, cut: bool) -> str:
    """Each JWT-shaped part replaced: from ``eyJ`` (the base64url of ``{"``) to the end of its
    run of base64url characters and dots, when that run holds at least two dots after ``eyJ``.
    When the text was cut, the run at its very end is replaced if it holds ``eyJ`` at all. A run
    that does not match is skipped whole."""
    out: list[str] = []
    copied = 0
    start = text.find("eyJ")
    while start >= 0:
        run = _RUN.match(text, start)
        end = run.end() if run is not None else start + 3
        if text.count(".", start, end) >= 2 or (cut and end == len(text)):
            out.append(text[copied:start])
            out.append(REDACTED)
            copied = end
        start = text.find("eyJ", end)
    if not out:
        return text
    out.append(text[copied:])
    return "".join(out)


def redact(text: str) -> str:
    """``text`` with every token-shaped part replaced by ``[REDACTED]``."""
    cut = len(text) > MAX_LENGTH
    if cut:
        text = text[:MAX_LENGTH]
    text = _AUTHORIZATION.sub(_authorization, text)
    text = _BEARER.sub(lambda m: f"{m.group(1)} {REDACTED}", text)
    text = _jwts(text, cut)
    return text + TRUNCATED if cut else text

"""The request context (FR-12): the request ID and the incoming trace context, held in a
``contextvars.ContextVar`` for the request or the work it runs.

``outgoing_headers`` gives what an internal call passes on and ``log_fields`` what each log line
carries. When the service has its own active, recording OpenTelemetry span, that span's context is
used instead of the incoming one (FR-12.6); the library never starts a span or touches the tracer
provider."""

from __future__ import annotations

from collections.abc import Iterator, Sequence
from contextlib import contextmanager
from contextvars import ContextVar
from dataclasses import dataclass
from typing import TYPE_CHECKING, Final

from opentelemetry import trace

from webblock_commons.core.traceparent import (
    TraceParent,
    parse_traceparent,
    request_id_from,
    tracestate_from,
)

if TYPE_CHECKING:
    from webblock_commons.core.caller import Caller
    from webblock_commons.core.user import WebBlockUser

REQUEST_ID: Final = "x-request-id"
TRACEPARENT: Final = "traceparent"
TRACESTATE: Final = "tracestate"
USER_ID: Final = "x-user-id"
XFCC: Final = "x-forwarded-client-cert"
DEV_CALLER: Final = "x-webblock-dev-caller"
"""The header names the library reads or sets (FR-7, FR-9, FR-12, FR-13), in lower case."""

_CURRENT: Final[ContextVar[RequestContext | None]] = ContextVar(
    "webblock_commons_request", default=None
)


@dataclass(slots=True)
class RequestContext:
    """One request's or one piece of work's context. Holds no token."""

    request_id: str
    traceparent: TraceParent | None = None
    tracestate: str | None = None
    user: WebBlockUser | None = None
    caller: Caller | None = None
    system: bool = False
    """True for an inner call or background work: the user, if any, never comes from a token."""

    @property
    def trace_id(self) -> str | None:
        active = active_trace(self)
        return active[0].trace_id if active else None


def incoming(
    request_ids: Sequence[str], traceparents: Sequence[str], tracestates: Sequence[str]
) -> RequestContext:
    """The context of an incoming request or message from its header values (each list holds every
    value of that header). A bad request ID is replaced; a bad or repeated ``traceparent`` is
    dropped together with its ``tracestate``."""
    parent = parse_traceparent(traceparents[0]) if len(traceparents) == 1 else None
    return RequestContext(
        request_id=request_id_from(request_ids),
        traceparent=parent,
        tracestate=tracestate_from(tracestates) if parent else None,
    )


def current() -> RequestContext | None:
    """The context of the running request or work, or None outside one."""
    return _CURRENT.get()


@contextmanager
def bound(ctx: RequestContext) -> Iterator[RequestContext]:
    """Makes ``ctx`` the current context inside the ``with`` block. When the block ends in another
    context (an async generator closed by another task), the variable is cleared there instead."""
    token = _CURRENT.set(ctx)
    try:
        yield ctx
    finally:
        try:
            _CURRENT.reset(token)
        except ValueError:
            _CURRENT.set(None)


def active_trace(ctx: RequestContext | None) -> tuple[TraceParent, str | None] | None:
    """The trace context to log and pass on: the service's recording span when there is one,
    else the incoming one of ``ctx``."""
    span = trace.get_current_span()
    span_context = span.get_span_context()
    if span_context.is_valid and span.is_recording():
        trace_id = f"{span_context.trace_id:032x}"
        span_id = f"{span_context.span_id:016x}"
        flags = f"{int(span_context.trace_flags):02x}"
        header = f"00-{trace_id}-{span_id}-{flags}"
        state = span_context.trace_state.to_header() or None
        return TraceParent("00", trace_id, span_id, flags, header), state
    if ctx is None or ctx.traceparent is None:
        return None
    return ctx.traceparent, ctx.tracestate


def outgoing_headers() -> dict[str, str]:
    """``x-request-id``, ``traceparent`` and ``tracestate`` (when present) of the current context;
    empty outside one."""
    ctx = current()
    if ctx is None:
        return {}
    headers = {REQUEST_ID: ctx.request_id}
    active = active_trace(ctx)
    if active is not None:
        headers[TRACEPARENT] = active[0].header
        if active[1]:
            headers[TRACESTATE] = active[1]
    return headers


# Headers an internal call or a message never takes from anyone but the library: the ones it sets,
# and the ones that would carry a user, a token or a caller (FR-9, FR-13).
OWN_HEADERS: Final = frozenset(
    {
        REQUEST_ID,
        TRACEPARENT,
        TRACESTATE,
        USER_ID,
        "authorization",
        "proxy-authorization",
        "cookie",
        XFCC,
        DEV_CALLER,
    }
)


def internal_headers() -> dict[str, str]:
    """What an internal call carries: ``outgoing_headers`` and, when there is a current user,
    ``x-user-id`` with that user's ID (never a value copied from the incoming request)."""
    headers = outgoing_headers()
    ctx = current()
    if ctx is not None and ctx.user is not None:
        headers[USER_ID] = str(ctx.user.user_id)
    return headers


def log_fields() -> dict[str, str]:
    """``request_id``, ``trace_id`` and ``span_id`` of the current context, each when known."""
    ctx = current()
    fields: dict[str, str] = {}
    if ctx is not None:
        fields["request_id"] = ctx.request_id
    active = active_trace(ctx)
    if active is not None:
        fields["trace_id"] = active[0].trace_id
        fields["span_id"] = active[0].span_id
    return fields

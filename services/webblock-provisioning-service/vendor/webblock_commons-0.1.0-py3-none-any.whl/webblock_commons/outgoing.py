"""HTTP calls to our own services (FR-9): only clients the service marks as internal are changed.

``internal_client`` builds an ``httpx2.AsyncClient`` whose transport, on every request, removes
``Authorization``, ``Proxy-Authorization``, ``Cookie`` and every header only the library may set,
then adds ``x-request-id``,
``traceparent``, ``tracestate`` and the current user's ``x-user-id``. It follows no redirect: the
client does not follow, and the transport drops ``Location`` from any 3xx answer, so a redirect to
an outside host is never taken. A client built any other way is never touched."""

from __future__ import annotations

from typing import Any, Final

import httpx2

from webblock_commons.core.context import OWN_HEADERS, internal_headers

__all__ = ["InternalTransport", "internal_client", "internal_headers"]


class InternalTransport(httpx2.AsyncBaseTransport):
    """Wraps a transport (the default one when none is given) with the internal call rules."""

    def __init__(self, inner: httpx2.AsyncBaseTransport | None = None) -> None:
        self._inner = inner if inner is not None else httpx2.AsyncHTTPTransport()

    async def handle_async_request(self, request: httpx2.Request) -> httpx2.Response:
        for name in OWN_HEADERS:
            request.headers.pop(name, None)
        request.headers.update(internal_headers())
        response = await self._inner.handle_async_request(request)
        if 300 <= response.status_code < 400:
            response.headers.pop("location", None)
        return response

    async def aclose(self) -> None:
        await self._inner.aclose()


_BYPASS: Final = ("mounts", "proxy", "proxies")
"""Options that would send a request through another transport than the wrapped one."""


def internal_client(**options: Any) -> httpx2.AsyncClient:
    """An ``httpx2.AsyncClient`` for calls to our own services. ``options`` are passed on;
    ``transport`` is wrapped; ``follow_redirects=True`` and the options that would bypass the
    wrapped transport (``mounts``, ``proxy``, ``proxies``) are refused."""
    if options.pop("follow_redirects", False):
        raise ValueError("internal_client: an internal client follows no redirect")
    bypass = [name for name in _BYPASS if name in options]
    if bypass:
        raise ValueError(f"internal_client: {', '.join(bypass)} would bypass the internal rules")
    transport = InternalTransport(options.pop("transport", None))
    return httpx2.AsyncClient(transport=transport, follow_redirects=False, **options)
